package com.controllers;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

//import org.json.JSONArray;
//import org.json.JSONException;
//import org.json.JSONObject;
//import com.google.gson.JsonArray;
public class Result {

    public String url;
    public String content;
    public String title;
    public String seq = "" + 0;

}
