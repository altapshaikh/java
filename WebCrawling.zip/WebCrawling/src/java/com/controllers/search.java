/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controllers;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Shri
 */
public class search extends HttpServlet {

    String links[] = new String[50];
    String hylink[] = new String[50];
    int kk1 = 0;
    int kk2 = 0;
    String pLink = "";
    String hLink = "";
    static ArrayList snipList = new ArrayList();
    static ArrayList list1 = new ArrayList(); // link
    static ArrayList list2 = new ArrayList(); // click
    static ArrayList list3 = new ArrayList(); // binary
    List<String> vals = new ArrayList<String>();
    final String filepath = "E:/";
    public String finalquery = "";
    static int ck = 0;
    public String firstQuery = "";
    String[] engines = {"quora", "stackoverflow", "youtube"};
   

    int m;
    HttpServletRequest r;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession hs = request.getSession();
        String name = hs.getAttribute("name").toString();           //create session
        String email = hs.getAttribute("email").toString();
        Cluster cluster = Cluster.builder().addContactPoint("127.0.0.1").build();
        Session session = cluster.connect("db_crawling");

        try {
            /* TODO output your page here. You may use following sample code. */
            String qry = request.getParameter("query").trim();
            boolean flag = true;
            r = request;
            String queries = "";
            ArrayList<String> ee = new ArrayList();
            String qq = "select * from query_table";
            ResultSet rs = session.execute(qq);
            for (Row rp : rs) {
                ee.add(rp.getString("query"));
            }
            for (m = 0; m < engines.length; m++) {
                if (!ee.contains("" + qry + " " + engines[m])) {
                    Search(qry + " " + engines[m]);
                    queries = queries + "" + qry + " " + engines[m] + ",";

                    System.out.println("Result" + queries);
                } else {
                    queries = queries + "" + qry + " " + engines[m] + ",";
                    System.out.println("Result already found...");

                }

            }
            if (queries.contains(",")) {
                queries.substring(0, queries.lastIndexOf(","));
            }
            hs.setAttribute("name", name);           //create session
            hs.setAttribute("email", email);
            hs.setAttribute("queries", queries);

            response.sendRedirect("searchquery.jsp?flag=" + flag + "");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public List Search(String qry) {

        try {
            Cluster cluster = Cluster.builder().addContactPoint("127.0.0.1").build();
            Session session = cluster.connect("db_crawling");
            finalquery = qry;
            String str1 = "http://www.google.co.in/search?hl=en&source=hp&q=";
            // http://www.google.co.in/search?hl=en&source=hp&q=data+mining      
            String[] tmp = qry.split(" ");
            str1 = str1 + qry.replace(" ", "+");
            firstQuery = tmp[0];
            str1 = str1 + "&meta=&aq=f&oq=&start=0";
            System.out.println("Qry:  " + str1 + " and Base query=: " + firstQuery);

            URL url1 = new URL(str1);

            URLConnection uc1 = url1.openConnection();
            uc1.addRequestProperty("User-Agent", "Mozilla/4.76");

            BufferedReader br1 = new BufferedReader(new InputStreamReader(uc1.getInputStream()));
            String pc1 = "";
            String pcnt1 = "";

            while ((pc1 = br1.readLine()) != null) {
                System.out.println(" PC1: " + pc1);
                pcnt1 = pcnt1 + pc1;
            }
            String test1 = pcnt1.substring(pcnt1.indexOf("results"), pcnt1.length());
            String lk1[] = test1.split("<p>");

            int len1 = lk1.length;
            System.out.println(len1);
            if (len1 > 15) {
                len1 = 5;
            } else {
                len1 = 5;
            }

            String np = "<html><body>";
            Result res = new Result();
            for (int i = 1; i < len1; i++) {

                lk1[i] = lk1[i].replace("/url?q=", "");
                if (!engines[m].contains("youtube")) {
                    if (lk1[i].contains("&amp")) {
                        int firstIndex = lk1[i].indexOf("&amp");
                        int lastIndex = lk1[i].indexOf("\">");
                        String gg = lk1[i].substring(firstIndex, lastIndex);
                        lk1[i] = lk1[i].replace(gg, "");
                    }
                } else {
                    if (lk1[i].contains("%3F")) {
                        lk1[i] = lk1[i].replace("%3F", "?");
                        lk1[i] = lk1[i].replace("%3D", "=");
                    }
                }
                System.out.println("" + lk1[i]);
                np = np + lk1[i];
                snipList.add(lk1[i]);
                String g1 = lk1[i];
                links[kk1++] = g1;
                pLink = pLink + g1 + "@";

                System.out.println("Printing ==>  " + lk1[i]);
                list1.add(g1);
                list2.add("0");
                list3.add("0");
                System.out.println(g1);
                vals.add(g1);
                System.out.println("Reached: " + i);
            }
            np = np + "</body></html>";

            String path = r.getSession().getServletContext().getRealPath("/");
            path = path.replaceAll("build", "");
            path = path + "query/";
            File f1 = new File(path + "\\" + qry + ".html");
            FileOutputStream fos = new FileOutputStream(f1);
            fos.write(np.getBytes());
            fos.close();
          
            String query = "insert into query_table (query,result) values ('" + qry + "','" + np + "')";
            ResultSet rs = session.execute(query);
            System.out.println(vals);
            return vals;
        } catch (Exception e) {
            e.printStackTrace();
            return vals;
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
