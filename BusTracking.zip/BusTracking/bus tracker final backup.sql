-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.19


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema bus
--

CREATE DATABASE IF NOT EXISTS bus;
USE bus;

--
-- Definition of table `buses`
--

DROP TABLE IF EXISTS `buses`;
CREATE TABLE `buses` (
  `id` varchar(50) NOT NULL DEFAULT '',
  `Source` varchar(50) NOT NULL,
  `Destination` varchar(50) NOT NULL,
  `lat` varchar(50) DEFAULT NULL,
  `lon` varchar(50) DEFAULT NULL,
  `Stime` time NOT NULL,
  `scount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buses`
--

/*!40000 ALTER TABLE `buses` DISABLE KEYS */;
INSERT INTO `buses` (`id`,`Source`,`Destination`,`lat`,`lon`,`Stime`,`scount`) VALUES 
 ('102','Chennai','Vellore','19.099300','74.731521','10:00:00',0),
 ('103','Pune','Nashik','19.099300','74.731521','10:00:00',NULL),
 ('897','asdfas','sdaf','19.099300','74.731521','00:00:10',0),
 ('103','Pune','Chakan','19.099300','74.731521','10:00:00',NULL),
 ('103','chakan','narayangaon','19.099300','74.731521','11:00:00',NULL),
 ('103','chakan','nashik','19.099300','74.731521','11:00:00',NULL);
/*!40000 ALTER TABLE `buses` ENABLE KEYS */;


--
-- Definition of table `calls`
--

DROP TABLE IF EXISTS `calls`;
CREATE TABLE `calls` (
  `id` varchar(50) NOT NULL,
  `source` varchar(50) NOT NULL,
  `Destination` varchar(50) NOT NULL,
  `time` varchar(50) NOT NULL,
  `seatno` varchar(50) NOT NULL,
  `userid` varchar(50) NOT NULL,
  PRIMARY KEY (`id`,`time`,`seatno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `calls`
--

/*!40000 ALTER TABLE `calls` DISABLE KEYS */;
INSERT INTO `calls` (`id`,`source`,`Destination`,`time`,`seatno`,`userid`) VALUES 
 ('103','chakan','nashik','11:00:00','1','dinesh@gmail.com'),
 ('103','chakan','nashik','11:00:00','2','dinesh@gmail.com');
/*!40000 ALTER TABLE `calls` ENABLE KEYS */;


--
-- Definition of table `conductor`
--

DROP TABLE IF EXISTS `conductor`;
CREATE TABLE `conductor` (
  `ID` varchar(50) NOT NULL,
  `cname` varchar(50) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `busid` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`uname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `conductor`
--

/*!40000 ALTER TABLE `conductor` DISABLE KEYS */;
INSERT INTO `conductor` (`ID`,`cname`,`uname`,`pass`,`busid`) VALUES 
 ('101','testt','testt','testt','103');
/*!40000 ALTER TABLE `conductor` ENABLE KEYS */;


--
-- Definition of table `newbuses`
--

DROP TABLE IF EXISTS `newbuses`;
CREATE TABLE `newbuses` (
  `id` varchar(45) NOT NULL,
  `source` varchar(45) DEFAULT NULL,
  `s1` varchar(45) DEFAULT NULL,
  `s2` varchar(45) DEFAULT NULL,
  `s3` varchar(45) DEFAULT NULL,
  `s4` varchar(45) DEFAULT NULL,
  `lat` varchar(45) DEFAULT NULL,
  `lon` varchar(45) DEFAULT NULL,
  `STime` time DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newbuses`
--

/*!40000 ALTER TABLE `newbuses` DISABLE KEYS */;
INSERT INTO `newbuses` (`id`,`source`,`s1`,`s2`,`s3`,`s4`,`lat`,`lon`,`STime`) VALUES 
 ('103','Pune','chakan','narayangaon','sangamner','Nashik',NULL,NULL,'10:00:00');
/*!40000 ALTER TABLE `newbuses` ENABLE KEYS */;


--
-- Definition of table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `emailid` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `mno` varchar(50) NOT NULL,
  `mobile1` varchar(45) DEFAULT NULL,
  `mobile2` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`emailid`,`password`,`uname`,`mno`,`mobile1`,`mobile2`) VALUES 
 ('dinesh@gmail.com','12345','dinesh','9503986854','8856915463','8856915463'),
 ('shubhangi@gmail.com','12345','shubangi','9890430022','8856915463','8856915463'),
 ('ss@gmail.com','12345','ss','8149877079','9637287768;','7972929432'),
 ('re@gmail.com','12345','testing','8149877079','9637287768','7972929432');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
