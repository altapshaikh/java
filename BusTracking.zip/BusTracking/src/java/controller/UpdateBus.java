/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import connection.DBConnection;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author shri
 */
public class UpdateBus extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            HttpSession httpSession = request.getSession(false);
            String username = httpSession.getAttribute("username").toString();
            httpSession.setAttribute("username", username);
            String address = request.getParameter("source");
            String busid = request.getParameter("busid");

            Float latLongs[];
            Float Latitude, Longitude;
            latLongs = GeoLocation.getLatLongPositions(address);
            System.out.println("Latitude: " + latLongs[0] + " and Longitude: " + latLongs[1]);
            Latitude = latLongs[0];
            Longitude = latLongs[1];

            String str = "UPDATE buses SET lat='" + Latitude + "', lon='" + Longitude + "' WHERE id='" + busid + "'";
            DBConnection db = new DBConnection();
            int r = db.Update(str);

            String str1 = "UPDATE  calls SET status='invalid' WHERE id='" + busid + "' AND Destination='" + address + "'";
            int r1 = db.Update(str1);
            
                out.println("<script type=\"text/javascript\">");
                out.println("alert('update location!');");
                out.println("location='updateLocation.jsp';");
                out.println("</script>");
                return;
            

        } catch (Exception e) {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Not update location!');");
            out.println("location='updateLocation.jsp';");
            out.println("</script>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
